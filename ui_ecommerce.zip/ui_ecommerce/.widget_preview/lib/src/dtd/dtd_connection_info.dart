// ignore_for_file: implementation_imports

const String kWidgetPreviewDtdUri = 'ws://127.0.0.1:58063/-52FyA9nJ4g=';
const String kWidgetPreviewService =
    'widget-preview-4562d03e-087e-461f-966b-72bf23942b13';
const String kWidgetPreviewScaffoldStream =
    'WidgetPreviewScaffold-4562d03e-087e-461f-966b-72bf23942b13';
const String kProjectRootPath =
    r'C:\Users\USER\OneDrive\Documents\Belajar-kls-11\SKL-Praktek\ui_ecommerce';
